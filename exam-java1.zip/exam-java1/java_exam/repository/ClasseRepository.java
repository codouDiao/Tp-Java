package java_exam.repository;



import java.util.List;

import java_exam.Entities.Classe;

public class ClasseRepository {
  
    public List<Classe> listerClasses() {
        // Code pour récupérer les classes depuis la base de données
        // Retourner la liste des classes
        return null;
    }

   
}

