package java_exam.repository;



import java.util.List;

import java_exam.Entities.Etudiant;

public class EtudiantRepository {
   
    public List<Etudiant> listerEtudiants() {
        // Code pour récupérer les étudiants depuis la base de données
        // Retourner la liste des étudiants
        return null;
    }

    // Autres méthodes CRUD à implémenter ici
}

