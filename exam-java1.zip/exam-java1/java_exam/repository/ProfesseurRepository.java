package java_exam.repository;



import java.util.List;

import java_exam.Entities.Professeur;

public class ProfesseurRepository {
    
    public List<Professeur> listerProfesseurs() {
        // Code pour récupérer les professeurs depuis la base de données
        // Retourner la liste des professeurs
        return null;
    }

    // Autres méthodes CRUD à implémenter ici
}

